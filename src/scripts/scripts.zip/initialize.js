import scene from './components/scene'

window.onload = function() {

	scene.init();

}
